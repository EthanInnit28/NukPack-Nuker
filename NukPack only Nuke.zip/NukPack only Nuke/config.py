names = ["ꜰᴜᴄᴋᴇᴅ ʙʏ ɴᴜᴋᴘᴀᴄᴋꜱǫ", "ꜱᴜᴄᴀ", "ᴀʜᴀʜᴀʜᴀᴀʜᴀʜᴀʜᴀ", "🤡", "🤡","🖕" ]
message = """
# @everyone FUCKED BY 

## NUCKPACKSQ

discord.gg/nukpacksq

"""
token = "Token"